import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background",
  {
    variants: {
      variant: {
        default:
          "border-transparent gradient-primary text-primary-foreground shadow-[0_4px_14px_-4px_oklch(0_0_0/50%)]",
        secondary: "border-border bg-secondary/70 text-secondary-foreground",
        outline: "border-border text-foreground/90",
        destructive: "border-transparent bg-destructive text-destructive-foreground",
        success:
          "border-transparent bg-[color-mix(in_oklab,var(--brand-cyan)_25%,transparent)] text-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
